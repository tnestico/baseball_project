#### NAME: THOMAS NESTICO
#### DATE: 2023-01-26


#import packages
import pandas as pd
import json
import numpy as np
import requests
import time
import os

pd.options.mode.chained_assignment = None 


print('AUTHOR: THOMAS NESTICO')
print('SUBMISSION DATE: 2023-01-26\n')
######THE PURPOSE OF THIS CODE IS TO SCRAPE AND TRANSFORM DATA FROM THE MLB API FOR THE GENERATION OF A PLAYER CARD######

## Create a dataframe of teams to assist with selecting a player to search
#Specifically for the case where multiple players share the same name
#Make an api call to get a dictionary of all teams
teams =  requests.get(url='https://statsapi.mlb.com/api/v1/teams/').json()
#Select only teams that are at the MLB level
mlb_teams_city = [x['franchiseName'] for x in teams['teams'] if x['sport']['name'] == 'Major League Baseball']
mlb_teams_name = [x['teamName'] for x in teams['teams'] if x['sport']['name'] == 'Major League Baseball']
mlb_teams_franchise = [x['name'] for x in teams['teams'] if x['sport']['name'] == 'Major League Baseball']
mlb_teams_id = [x['id'] for x in teams['teams'] if x['sport']['name'] == 'Major League Baseball']
mlb_teams_abb = [x['abbreviation'] for x in teams['teams'] if x['sport']['name'] == 'Major League Baseball']

#Create a dataframe of all the teams 
mlb_teams_df = pd.DataFrame(data={'id':mlb_teams_id,'city':mlb_teams_franchise,'name':mlb_teams_name,'franchise':mlb_teams_franchise,'abbreviation':mlb_teams_abb})


##Create a dataframe of all players in the database
#Make an api call to get a dictionary of all players
player_data = requests.get(url='https://statsapi.mlb.com/api/v1/sports/1/players').json()

#Select relevant data that will help distinguish players from one another
fullName_list = [x['fullName'] for x in player_data['people']]
id_list = [x['id'] for x in player_data['people']]
position_list = [x['primaryPosition']['abbreviation'] for x in player_data['people']]
team_list = [x['currentTeam']['id']for x in player_data['people']]

#Create a dataframe of players and their current team ids
player_df_all = pd.DataFrame(data={'id':id_list,'name':fullName_list,'position':position_list,'team_id':team_list})
#Use the teams dataframe to merge the team name to the players dataframe
player_df_all = player_df_all.merge(right=mlb_teams_df[['id','franchise']],left_on='team_id',right_on='id',how='left',suffixes=['','_y'])
#drop the duplicated id column
player_df_all = player_df_all.drop(columns=['id_y'])
#make a column of the names all uppercase to make lookups easier
player_df_all['upper_name'] = player_df_all['name'].str.upper()
#rename to make the data clearer
player_df_all = player_df_all.rename(columns={'franchise':'currentTeam'})

##Player Name input
#Input a player name
name = input('Please input a player name:\n')

#Ensure that the player is in the data frame
while sum(player_df_all.upper_name.isin([name.upper()]))<1:
    #If the player is not found, ask for the input again
    print('Invalid player name input\n')
    name = input('Please input a player name:\n')

#Check if the player name is unique
if  sum(player_df_all.upper_name.isin([name.upper()])) == 1:
    player_id = player_df_all.loc[player_df_all.upper_name == name.upper()].id.reset_index().loc[0].id
    

#If the player name is not unique
else:
    #Print a dataframe of the players
    print(player_df_all.loc[player_df_all.upper_name == name.upper()].reset_index(drop=True))
    #Select the desired player using their row index
    row_index = abs(int(input('Select which player based on row index\n')))
    while len(player_df_all.loc[player_df_all.upper_name == name.upper()]) < row_index+1:
        #If the row index is out of range, ask for row index again
        row_index = int(input('Select which player based on row index\n'))
    player_id = player_df_all.loc[(player_df_all.upper_name == name.upper())].reset_index().loc[row_index].id

#Check if player is a Two-Way Player (The Ohtani Check)
#If they are, input 'P' for pitcher or their position (i.e. DH for Designated Hitter)
player_position = player_df_all.loc[player_df_all.id == player_id].position.reset_index(drop=True)[0]
if player_position == 'TWP':
    print('Positions: ')
    print(player_df_all['position'].unique())
    player_position = input('Two-Way Player Selected. Please Input Position of Player\n').upper()

    while not player_position in player_df_all['position'].unique() or player_position == 'TWP':
        #Select a valid position
        player_position = input('Invalid Position. Please Input Position of Player\n').upper()

print('\nGenerating Player Card. Please Wait\n')

###Player Data Collection

##Make API Call to get the players Current team, awards, and year by year stats
#Check if the player is a hitter or pitcher (Ohtani Rule)
if player_position != 'P':
    player_card_api_call = requests.get(url=f"https://statsapi.mlb.com/api/v1/people?personIds={player_id}&appContext=majorLeague&"
                "hydrate=currentTeam,awards,"
                "stats(group=[hitting],type=[yearByYear])").json()
#Check if the player is a hitter or pitcher (Ohtani Rule)             
if player_position == 'P':
    player_card_api_call = requests.get(url=f"https://statsapi.mlb.com/api/v1/people?personIds={player_id}&appContext=majorLeague&"
                "hydrate=currentTeam,awards,"
                "stats(group=[pitching],type=[yearByYear])").json()

#Create a variable with the relevant information 
player_card_api_call_small = player_card_api_call['people'][0]

#Check if player has a number
if 'primaryNumber' not in player_card_api_call_small:
    #If they do not, create the key and leave it blank
    player_card_api_call_small['primaryNumber'] = 'N/A'
#List of relevant bio data
player_card_api_call_small_keys = ['id','lastName','firstName','primaryNumber','height','weight','birthDate','birthCity']
#Create a new dictionary of only the relevant bio data
out = {x: player_card_api_call_small[x] for x in player_card_api_call_small_keys}

#Check if the player has a state/province they were born in 
if 'birthStateProvince' in player_card_api_call_small:
    out['birthState'] = player_card_api_call_small['birthStateProvince']
else:
    out['birthState'] = ''

out['birthCountry'] = player_card_api_call_small['birthCountry']

#Check if the player was drafted in the MLB Amateur Draft
if 'draftYear' in player_card_api_call_small:
    #Gather all relevant Draft Data
    out['draftYear'] = player_card_api_call_small['draftYear']
    player_draft = requests.get(url='https://statsapi.mlb.com/api/v1/draft/'+str(out['draftYear'])+'?playerId='+str(out['id'])).json()['drafts']['rounds'][0]['picks'][0]
    out['draftTeam']  = mlb_teams_df[mlb_teams_df['id']==player_draft['team']['id']].reset_index(drop=True)['abbreviation'][0]
    out['draftRound']  = player_draft['pickRound']
    out['draftPick'] = player_draft['pickNumber']
    out['schoolName']  = player_draft['school']['name']
#If the player has no draft data, leave the fields blank
else:
    out['draftYear'] = ''
    out['draftTeam']  = ''
    out['draftRound']  = ''
    out['draftPick'] = ''
    out['schoolName']  = ''

#Input remiaing bio data in the dictionary
out['headshot'] = f'https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic:headshot:67:current.png/w_213,q_auto:best/v1/people/{player_id}/headshot/67/current'
out['bats'] = player_card_api_call_small['batSide']['description']
out['throws'] = player_card_api_call_small['pitchHand']['description']
out['position'] = player_position


#Create dataframe of bio data
df_bio = pd.DataFrame(out,index=[0])
df_bio = df_bio[['id','lastName','firstName','primaryNumber','height','weight','birthDate','birthCity','birthState',
                        'birthCountry','headshot','draftTeam','draftYear','draftRound','draftPick','bats','throws','schoolName','position']]

##Award Data
#Create lists for all relevant award data
award_player_id = [x['player']['id'] for x in player_card_api_call_small['awards']]
award_name = [x['name'] for x in player_card_api_call_small['awards']]
award_team = [x['team']['id'] for x in player_card_api_call_small['awards']]
award_season = [x['season'] for x in player_card_api_call_small['awards']]

#A short list of awards were selected for simplification in creating the player card
mlb_awards = ["Rawlings AL Gold Glove",
                     "Rawlings NL Gold Glove",
                     "AL Rookie of the Year",
                     "NL Rookie of the Year",
                     "AL All-Star",
                     "NL All-Star",
                     "AL MVP",
                     "NL MVP",
                     "AL Silver Slugger",
                     "NL Silver Slugger",
                     'AL Cy Young',
                     'NL Cy Young']

#Create award adataframe
award_df = pd.DataFrame(data={'id':award_player_id,'name':award_name,'season':award_season,'team_id':award_team})
#Select all award from the mlb_awards list
award_df = award_df[award_df['name'].isin(mlb_awards)].drop(columns='team_id').reset_index(drop=True)

##Player Stats
#Make an API call to get player stats for year by year

#Initialize lists for different types of data 
season_list = []
stat_list = []
team_list = []
sport_list = []
game_type_list = []

#Iteraete through each season to gather the data
for i in player_card_api_call_small['stats'][0]['splits']:
    season_list.append(i['season'])
    stat_list.append(i['stat'])
    #If a player gets traded mid-season, they have data for each team and also the data for the entire season
    #They do not have a team assosciated with this season long stats
    #If the player has no team, fill in value with '---' 
    if 'team' in i:
        team_list.append(i['team'])
    else:
        team_list.append({'id':'---','name':'---','link':'---'})

    sport_list.append(i['sport'])
    game_type_list.append(i['gameType'])

#Create a dataframe for each list and add a prefix to help distinguish column names
player_stat_yearByYear_season = pd.DataFrame(data={'season':season_list})
player_stat_yearByYear_stat = pd.DataFrame(data=stat_list).add_prefix('stat.')
player_stat_yearByYear_team = pd.DataFrame(data=team_list).add_prefix('team.')
player_stat_yearByYear_sport = pd.DataFrame(data=sport_list).add_prefix('sport.')
player_stat_yearByYear_gameType = pd.DataFrame(data={'gameType':game_type_list})
#Join all the dataframes together to create a stats dataframe
player_stat_yearByYear = player_stat_yearByYear_season.join(player_stat_yearByYear_stat).join(player_stat_yearByYear_team).join(player_stat_yearByYear_sport).join(player_stat_yearByYear_gameType)
#Drop summed seasons in a seasons where a player was traded
player_stat_yearByYear = player_stat_yearByYear[player_stat_yearByYear['team.id']!='---'].reset_index(drop=True)
#Add in team abbreviation to the df
player_stat_yearByYear['team.abb'] = list(player_stat_yearByYear[['team.id']].merge(right=mlb_teams_df[['id','abbreviation']],left_on='team.id',right_on='id').drop(columns=['team.id','id'])['abbreviation'])

#Calculate other player statistics
#Batter Statistics
if player_position != 'P':
    #Strikeout Percentage K%
    player_stat_yearByYear['stat.strikeoutPercentage'] = player_stat_yearByYear['stat.strikeOuts']/player_stat_yearByYear['stat.plateAppearances']
    #Walk BB%
    player_stat_yearByYear['stat.baseOnBallPercentage'] = player_stat_yearByYear['stat.baseOnBalls']/player_stat_yearByYear['stat.plateAppearances']
    #Base on ball to Strikout ratio
    player_stat_yearByYear['stat.BB_K'] = player_stat_yearByYear['stat.baseOnBalls']/player_stat_yearByYear['stat.strikeOuts']
    #Extra Base Hits XBH
    player_stat_yearByYear['stat.extraBaseHits'] = player_stat_yearByYear['stat.doubles']+player_stat_yearByYear['stat.triples']+player_stat_yearByYear['stat.homeRuns']
    #Isolated Power, ISO
    player_stat_yearByYear['stat.iso'] = player_stat_yearByYear['stat.slg'].astype(float)-player_stat_yearByYear['stat.avg'].astype(float)
    #Singles, 1B
    player_stat_yearByYear['stat.singles'] = player_stat_yearByYear['stat.hits']-player_stat_yearByYear['stat.doubles']-player_stat_yearByYear['stat.triples']-player_stat_yearByYear['stat.homeRuns']

#Pitcher Statistics
if player_position == 'P':
    #Homerun percentage HR%
    player_stat_yearByYear['stat.homeRunPercentage'] = player_stat_yearByYear['stat.homeRuns']/player_stat_yearByYear['stat.battersFaced']
    #Strikeout Percentage K%
    player_stat_yearByYear['stat.strikeoutPercentage'] = player_stat_yearByYear['stat.strikeOuts']/player_stat_yearByYear['stat.battersFaced']
    #Walk Percentage BB%
    player_stat_yearByYear['stat.baseOnBallPercentage'] = player_stat_yearByYear['stat.baseOnBalls']/player_stat_yearByYear['stat.battersFaced']
    #K% - BB%
    player_stat_yearByYear['stat.strikeoutPercentage_baseOnBallPercentage'] = player_stat_yearByYear['stat.strikeoutPercentage'] - player_stat_yearByYear['stat.baseOnBallPercentage']
    #Base on ball to Strikout ratio
    player_stat_yearByYear['stat.BB_K'] = player_stat_yearByYear['stat.baseOnBalls']/player_stat_yearByYear['stat.strikeOuts']
    #Extra Base Hits XBH
    player_stat_yearByYear['stat.extraBaseHitsAllowed'] = player_stat_yearByYear['stat.doubles']+player_stat_yearByYear['stat.triples']+player_stat_yearByYear['stat.homeRuns']
    #Isolated Power, ISO
    player_stat_yearByYear['stat.isoAgainst'] = player_stat_yearByYear['stat.slg'].astype(float)-player_stat_yearByYear['stat.avg'].astype(float)
    #Singles, 1B
    player_stat_yearByYear['stat.singles'] = player_stat_yearByYear['stat.hits']-player_stat_yearByYear['stat.doubles']-player_stat_yearByYear['stat.triples']-player_stat_yearByYear['stat.homeRuns']

#Fill in any NaN values
player_stat_yearByYear = player_stat_yearByYear.fillna(0)


#Make an API call for sabermetrics
#Sabermetrics call requires a list of seasons to get multiple seasons
seasons_stat_list = str([int(x) for x in player_stat_yearByYear.season]).replace(' ','')
#The Ohtani check
if player_position != 'P':
    player_sabermetrics_yearByYear = requests.get(f'https://statsapi.mlb.com/api/v1/people?personIds={player_id}&hydrate=stats(group=[hitting],type=[sabermetrics],seasons={seasons_stat_list})').json()
if player_position == 'P':
    player_sabermetrics_yearByYear = requests.get(f'https://statsapi.mlb.com/api/v1/people?personIds={player_id}&hydrate=stats(group=[pitching],type=[sabermetrics],seasons={seasons_stat_list})').json()

#Intialize list
sabermetrics_list = []
n=0

#Go through each season
for i in player_sabermetrics_yearByYear['people'][0]['stats'][0]['splits']:
    sabermetrics_list.append(i['stat'])
    sabermetrics_list[n]['season'] = i['season']
    sabermetrics_list[n]['team.id'] = i['team']['id']
    n=n+1

#Drop any rows that are duplicated
sabermatrics_yearByYear = pd.DataFrame(sabermetrics_list).add_prefix('sabermetric.').drop_duplicates()
#Fill in any NaN values
sabermatrics_yearByYear = sabermatrics_yearByYear.fillna(0)
#Merge sabermetrics to the stats dataframe
player_stat_yearByYear = player_stat_yearByYear.merge(right=sabermatrics_yearByYear,left_on=['season','team.id'],right_on=['sabermetric.season','sabermetric.team.id'])


##Player Team Data
#Using the bio and stats df from before, we can create a dataframe consisting of all teams the player has played on
#Initialize dictionary
player_team_dict = {}
#Make a list consisting of current Team Data and the teams from the stats dateframe
player_team_dict['id'] = [player_card_api_call_small['currentTeam']['id']]+list(player_stat_yearByYear['team.id'])
player_team_dict['name'] = [player_card_api_call_small['currentTeam']['name']]+list(player_stat_yearByYear['team.name'])
player_team_dict['link'] = ['https://www.mlbstatic.com/team-logos/'+str(x)+'.svg' for x in player_team_dict['id']]
#Drop duplicated teams
player_team_dict_df = pd.DataFrame(player_team_dict).drop_duplicates()
#Remove any blank teams
player_team_dict_df = player_team_dict_df.loc[player_team_dict_df['id']!='---']
#Set all current teams to False
player_team_dict_df['currentTeam'] = len(player_team_dict_df)*[False]
#Only the first team will be current, set it to True
player_team_dict_df['currentTeam'][0] = True


##Select fields for the cards
#Batter
if player_position != 'P':
    batter_fields = ['season','team.abb','stat.gamesPlayed','stat.plateAppearances','stat.runs','stat.rbi','stat.homeRuns','stat.stolenBases','stat.baseOnBallPercentage',
                        'stat.strikeoutPercentage','stat.BB_K','stat.avg','stat.obp','stat.slg','sabermetric.woba','sabermetric.wRcPlus','sabermetric.war']
#Pitcher
if player_position == 'P':
    pitcher_fields = ['season','team.abb','stat.gamesPlayed','stat.wins','stat.losses','stat.saves','stat.inningsPitched','stat.era','stat.whip',
                        'stat.homeRunPercentage','stat.strikeoutPercentage','stat.baseOnBallPercentage','stat.strikeoutPercentage_baseOnBallPercentage','sabermetric.eraMinus','sabermetric.fipMinus','sabermetric.xfip','sabermetric.war']


##Final step in card data is calculating career Statistics
#Calculate career statistics
#Batter
if player_position != 'P':
    #Select only relevant stats for card
    card_stats = player_stat_yearByYear[batter_fields]
    #Sum up all fields first to intialize a dictionary and sum counting stats
    career_row = card_stats.sum()

    #Change career and team
    career_row['season'] = 'Career'
    career_row['team.abb'] = ''
        
    #Walk Percentage K%
    career_row['stat.baseOnBallPercentage'] = player_stat_yearByYear['stat.baseOnBalls'].sum()/player_stat_yearByYear['stat.plateAppearances'].sum()
    #Strikeout Percentage K%
    career_row['stat.strikeoutPercentage'] = player_stat_yearByYear['stat.strikeOuts'].sum()/player_stat_yearByYear['stat.plateAppearances'].sum()
    #Walk to Strikeout Ratio, K/BB
    career_row['stat.BB_K'] = career_row['stat.baseOnBallPercentage']/career_row['stat.strikeoutPercentage']
    


    #Batting Average, avg 
    career_row['stat.avg'] = player_stat_yearByYear['stat.hits'].sum()/ player_stat_yearByYear['stat.atBats'].sum()
    #on-Base Percentage, OBP
    career_row['stat.obp'] = (sum(np.array([float(x) for x in player_stat_yearByYear['stat.obp']]) * 
                                        np.array([x for x in player_stat_yearByYear['stat.plateAppearances']]))/(career_row['stat.plateAppearances']))
    #Slugging Percentage, SLG
    career_row['stat.slg'] = player_stat_yearByYear['stat.totalBases'].sum()/ player_stat_yearByYear['stat.atBats'].sum()

    #Calculate denominator for career wOBA, using Fangraphs 2019 wOBA formula
    woba_denominator_array = np.array([x for x in ([int(x) for x in player_stat_yearByYear['stat.atBats']+ player_stat_yearByYear['stat.baseOnBalls']+ 
                                        player_stat_yearByYear['stat.sacFlies']+ player_stat_yearByYear['stat.hitByPitch']- player_stat_yearByYear['stat.intentionalWalks']])])
    #Calculate wOBA using a weighted average                                  
    career_row['sabermetric.woba'] = (sum(np.array([x for x in player_stat_yearByYear['sabermetric.woba']]) * 
                                        np.array([x for x in woba_denominator_array]))/(woba_denominator_array.sum()))# career_row['sabermetric.fipMinus'] = sum(np.array([x for x in player_stat_yearByYear['sabermetric.fipMinus']]) * np.array([x for x in ([int(x[0])+int(x[1])*1/3 for x in card_stats['stat.inningsPitched'].str.split('.')])]))/innings_p


    #Calculate wRc+ using a weighted average  
    career_row['sabermetric.wRcPlus'] = sum(np.array([x for x in player_stat_yearByYear['sabermetric.wRcPlus']]) * 
                                        np.array([x for x in player_stat_yearByYear['stat.plateAppearances']]))/(career_row['stat.plateAppearances'])

    #Make df for card stats
    card_stats = card_stats.append(pd.DataFrame(data=[career_row])).reset_index(drop=True)
    #Change df column names
    card_columns = ['Season','Team','GP','PA','R','RBI','HR','SB','BB%','K%','BB/K','AVG','OBP','SLG','wOBA','wRC+','WAR']
    card_stats.columns = card_columns
    
    #Change df percision
    card_stats[card_stats.columns[10]] = card_stats[card_stats.columns[10]].astype(float).round(2)
    card_stats[card_stats.columns[11:15]] = card_stats[card_stats.columns[11:15]].astype(float).round(3)
    card_stats[card_stats.columns[15]] = card_stats[card_stats.columns[15]].astype(int)
    card_stats[card_stats.columns[16]] = card_stats[card_stats.columns[16]].astype(float).round(1)
    card_stats[card_stats.columns[8:10]] = ((round(card_stats[card_stats.columns[8:10]],3)*1000).astype(int)/10).astype(str)+'%'

#Pitcher
if player_position == 'P':
    #Select only relevant stats for card
    card_stats = player_stat_yearByYear[pitcher_fields]
    #Sum up all fields first to intialize a dictionary and sum counting stats
    career_row = card_stats.sum()

    #Change career and team
    career_row['season'] = 'Career'
    career_row['team.abb'] = ''

    #Calculate Innings Pitched as float for future calculations
    innings_p =float([str(sum([int(x[0])+int(x[1])*1/3 for x in card_stats['stat.inningsPitched'].str.split('.')]))][0])
    #Convert total innings pitched into a string for player card
    career_row['stat.inningsPitched'] = str(innings_p).split('.')
    career_row['stat.inningsPitched'] = str(round(int(career_row['stat.inningsPitched'][0]) + round(float(career_row['stat.inningsPitched'][1])/(10**(len(career_row['stat.inningsPitched'][1])+1)/3),1),1))
    
    #Earned Run Average, ERA
    career_row['stat.era'] = player_stat_yearByYear['stat.earnedRuns'].astype(float).sum()/innings_p*9
    #Walks plus hits per innings pitched, WHIP
    career_row['stat.whip'] = (player_stat_yearByYear['stat.baseOnBalls'].astype(float).sum()+player_stat_yearByYear['stat.hits'].astype(float).sum())/innings_p

    #Homerun Percentage, HR%
    career_row['stat.homeRunPercentage'] = player_stat_yearByYear['stat.homeRuns'].sum()/player_stat_yearByYear['stat.battersFaced'].sum()

    #Strikeout Percentage, K%
    career_row['stat.strikeoutPercentage'] = player_stat_yearByYear['stat.strikeOuts'].sum()/player_stat_yearByYear['stat.battersFaced'].sum()

    #Walk Percentage, BB%
    career_row['stat.baseOnBallPercentage'] = player_stat_yearByYear['stat.baseOnBalls'].sum()/player_stat_yearByYear['stat.battersFaced'].sum()

    #Strikeout Percentage minus Walk Percentage, K-BB%
    career_row['stat.strikeoutPercentage_baseOnBallPercentage'] = career_row['stat.strikeoutPercentage']-career_row['stat.baseOnBallPercentage']

    #Calculate ERA- using a weighted average  
    career_row['sabermetric.eraMinus'] = sum(np.array([x for x in player_stat_yearByYear['sabermetric.eraMinus']]) * np.array([x for x in ([int(x[0])+int(x[1])*1/3 for x in card_stats['stat.inningsPitched'].str.split('.')])]))/innings_p
    #Calculate FIP- using a weighted average  
    career_row['sabermetric.fipMinus'] = sum(np.array([x for x in player_stat_yearByYear['sabermetric.fipMinus']]) * np.array([x for x in ([int(x[0])+int(x[1])*1/3 for x in card_stats['stat.inningsPitched'].str.split('.')])]))/innings_p
    #Calculate xFIP using a weighted average  
    career_row['sabermetric.xfip'] = sum(np.array([x for x in player_stat_yearByYear['sabermetric.xfip']]) * np.array([x for x in ([int(x[0])+int(x[1])*1/3 for x in card_stats['stat.inningsPitched'].str.split('.')])]))/innings_p
    
    #Make df for card stats
    card_stats = card_stats.append(pd.DataFrame(data=[career_row])).reset_index(drop=True)
    #Change Column Names
    card_columns = ['Season','Team','GP','W','L','SV','IP','ERA','WHIP','HR%','K%','BB%','K-BB%','ERA-','FIP-','xFIP','WAR']
    card_stats.columns = card_columns

    #Change df percision
    card_stats[card_stats.columns[7:9]] = card_stats[card_stats.columns[7:9]].astype(float).round(2)
    card_stats[card_stats.columns[9:13]] = card_stats[card_stats.columns[9:13]].astype(float).round(3)
    card_stats[card_stats.columns[13:15]] = card_stats[card_stats.columns[13:15]].astype(int)
    card_stats[card_stats.columns[15]] = card_stats[card_stats.columns[15]].astype(float).round(2)
    card_stats[card_stats.columns[16]] = card_stats[card_stats.columns[16]].astype(float).round(1)
    card_stats[card_stats.columns[9:13]] = ((round(card_stats[card_stats.columns[9:13]],3)*1000).astype(int)/10).astype(str)+'%'


##Write df to csv
#For cards
df_bio.to_csv('sample_data/csv/person.csv')
award_df.to_csv('sample_data/csv/awards.csv')
card_stats.to_csv('sample_data/csv/stats_card.csv')
player_team_dict_df.to_csv('sample_data/csv/teams.csv')

#All stat fields, not used for cards
player_stat_yearByYear.to_csv('sample_data/csv/stats_yearByYear.csv')

##Write df to .xlsx for card generation
#For cards
df_bio.to_excel('sample_data/xlsx/person.xlsx')
award_df.to_excel('sample_data/xlsx/awards.xlsx')
card_stats.to_excel('sample_data/xlsx/stats_card.xlsx')
player_team_dict_df.to_excel('sample_data/xlsx/teams.xlsx')


#Directs user to open player card to see generated code
print('Open "player_card.xlsx" to view generated card')



flag = input('Would you like to open "player_card.xlsx"? (y/n)\n')
if flag == 'y':

    os.system("start EXCEL.EXE player_card.xlsx")
    print('Opening player_card.xlsx\n')
    print('Goodbye')
    time.sleep(5)

else:
    print('\nGoodbye')
    time.sleep(5)




